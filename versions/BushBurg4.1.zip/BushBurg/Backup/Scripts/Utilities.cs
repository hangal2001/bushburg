﻿using UnityEngine;
using System.Collections;

/* Stores functions not associated with any particular object
 * This class should not contain variables and should not
 * instantiate any objects*/

public class Utilities : MonoBehaviour 
{


}
